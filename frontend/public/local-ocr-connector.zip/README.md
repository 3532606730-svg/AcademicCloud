# AcademicCloud 本机 OCR 连接器

此包处理自己账户明确提交的当前页和私人整书任务。它不包含模型、账户令牌、Catalog 凭据或任何书页。每次启动重新配对，令牌仅存在本次进程内存。

## 已有 Owner 标准 WSL 引擎

1. 安装 Node.js24（官方页面：https://nodejs.org/en/download），解压本包。
2. 进入解压目录，运行 npm install。只安装固定版本画布和 PDF 渲染依赖，不下载 OCR 模型。
3. 在 AcademicCloud“我的研究”的 OCR 连接对话框创建连接码。
4. 在 AcademicCloudComputeV2 的 WSL 终端，以既有 academiccloud 用户进入本包目录，运行：

   npm start -- --core https://cloud.ajtlab.top --pair --detect-installed

5. 粘贴连接码并按 Enter。输入不会显示，日志不会打印令牌。看到 member_ocr.connected 后保留此终端，回网站识别当前页或明确开始私人整书后台任务。

标准共享 Owner 主机需要协调安装具备 native-resource.v1 的 Compute/Bridge 版本并配置相同资源锁。缺少合同会拒绝启动，不能通过删除检查绕过。Catalog 和成员 OCR 使用同一资源锁顺序运行。

共享锁与进程记录在服务用户的私人 coordination 目录中，由整包部署配置。其他 Linux 用户不能借此接入 Owner 主机；不要修改组或开放目录权限。进程异常终止后可能保留安全锁，此时会拒绝运行。管理员须确认后台服务、连接器与所有原生子进程都已停止，再在同一锁文件上执行受锁保护的恢复；不要删除锁文件或绕过检查。

## 其他成员自己的安装

只支持已安装的固定 PaddlePaddle3.3.1/PaddleOCR3.7.0 和 PP-OCRv6 small 两份固定权重。安装资料：https://www.paddleocr.ai/main/quick_start.html 和 https://www.paddlepaddle.org.cn/install/quick 。引擎和模型安装独立于本包，不能把任意安装版本当作已合格。
将 config.example.json 的绝对路径改为自己的 Python、两个模型、本包侧车和私人缓存目录。使用 Linux/WSL 与 Python3 fcntl 资源锁，运行：

   npm start -- --core https://cloud.ajtlab.top --pair --config /absolute/member-ocr.json

--config 与 --detect-installed 互斥；不读取生产.env。共享 Owner 标准主机不能用 sharedHost:false 绕过合作检查。

## 故障和停止

失去权限、连接码失效、缺少合作合同、引擎测试失败会显示受控错误代码；不要粘贴凭据或书页到日志。Catalog 忙碌时等待，不自动切换CPU/云端。整书使用私人临时文件并在停止后清理，每页确认保存后形成断点。关闭网站不会停止已开始的设备任务；本机与终端须持续运行并保持唤醒。关闭终端或 Ctrl+C 会停止本轮处理，等待原生引擎真正关闭后释放资源锁；已确认保存的页面保留。重启连接器或设备后须重新配对，并在网站手动继续、选择新连接。网站可暂停、取消任务或撤销设备；失败页面不自动重新识别。未校对机器文字与行框可能有漏字和表格读序问题；不支持传统蒙古文。结果保持私人，提供既有 TXT/JSONL 导出；本版不会生成可搜索 PDF 或替换线上原件。
